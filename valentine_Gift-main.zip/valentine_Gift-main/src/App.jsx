//src/App.jsx
import Valentine from "./components/Valentine";

export default function App() {
    return <Valentine />;
}